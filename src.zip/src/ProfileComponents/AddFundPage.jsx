// AddFundPage component
import React from 'react';

const AddFundPage = () => {
  return (
    <div>
      {/* Content of AddFundPage */}
      <h1>Add Fund Page Content</h1>
    </div>
  );
};

export default AddFundPage;
