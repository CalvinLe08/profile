import './App.css';
import Profile from './ProfileComponents/Profile';

function App(props) {
  return (
    <Profile/>
  );
}

export default App;
